export class User {

  fullName: string;

  emailId: string;

  password: string;

  age: number;
}
