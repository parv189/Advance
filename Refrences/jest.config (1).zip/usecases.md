## Password
- must contain special char, number
- Mixed case
- Minimum length: 6
- Max 20
- NOT Username
- NOT Radixweb8

## First Name + Last Name
- Minimum length: 6
- No digits/special characters

## Mail
- id - @ - domain - com.io
- restrict last domain (io/com)

## Age
- 18 <= age < 100
- only digits
- Max Three Digits



